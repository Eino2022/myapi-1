
$(document).ready(function(){

  $("#taskBtn1").click(function(){

    let numbers = $("#taskInput1:text").val();
    let httpParameters = "http://sum.myapi.localhost/?numbers=" + numbers;

    $.get(httpParameters, function(data, status){
      const myJSON = JSON.stringify(data);
      $("#resultLabel1").text(myJSON);
    });

  });

  $("#taskBtn2").click(function(){

    let number = $("#taskInput2:text").val();
    let httpParameters = "http://checkprime.myapi.localhost/?number=" + number;

    $.get(httpParameters, function(data, status){
      const myJSON = JSON.stringify(data);
      $("#resultLabel2").text(myJSON);
    });

  });

});
