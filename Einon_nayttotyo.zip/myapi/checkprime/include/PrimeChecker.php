<?php

class PrimeChecker
{
  public function __construct( ){
  }

  public function isPrime($n){
    for($x=2; $x<$n; $x++){
      if($n %$x == 0 ){
        return false;
      }
    }
    return true;
  }
}


?>
