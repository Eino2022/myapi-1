<?php

/*
  Eino Leinonen 2022.
*/

header('Content-Type: application/json; charset=utf-8;');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

include('include/PrimeChecker.php');

error_reporting(E_ALL ^ E_DEPRECATED);
ini_set('display_errors', '1');
session_start();

$httpOkRespNumber = 200;
$httpRespText = null;
$httpInfoText = "";
$jsonResult = [];

$isInt = false;

  if (isset($_GET['number'])) {

    $number = trim($_GET['number']);
    if( !is_numeric($_GET['number']) || $number != (int)$number ){
      $httpInfoText = " (value is not integer)";
    }else{
      $isInt = true;
    }
  }

  if($isInt==true && isset($_GET['number'])){

    /* calculate and define result */
    $primeChecker = new PrimeChecker();
    $isPrime = $primeChecker->isPrime($_GET['number']);

    /* responce result */
    $jsonResult['isPrime'] = $isPrime;
    echo json_encode($jsonResult);
    http_response_code($httpOkRespNumber);

  }else{

    /* else, parameter not found or parameter is illegal */
    $httpBadRequest = 400;
    $httpRespText = "404 Not Found $httpInfoText";
    $jsonResult['result'] = "undefined";
    $jsonResult['isPrime'] = "undefined";
    $jsonResult['error'] = "number not defined $httpInfoText";
    echo json_encode($jsonResult);
    http_response_code($httpBadRequest);
    header(trim("HTTP/1.1 $httpBadRequest $httpRespText"));
  }

?>
