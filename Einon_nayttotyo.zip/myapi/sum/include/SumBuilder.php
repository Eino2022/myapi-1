<?php
class SumBuilder
{
  public function __construct( ){
  }

  public function calculateSum($_numbers){

    $result = 0;

    if ($_numbers) {

      $numbers = explode(",",$_numbers);

      foreach ($numbers as $value) {
         $result += intval($value);
      }
    }

    return $result;
  }

}

?>
