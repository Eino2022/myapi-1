<?php

/*
  Eino Leinonen 2022.
*/

header('Content-Type: application/json; charset=utf-8;');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

include('include/SumBuilder.php');
include('../checkprime/include/PrimeChecker.php');

error_reporting(E_ALL ^ E_DEPRECATED);
ini_set('display_errors', '1');
session_start();

$httpOkRespNumber = 200;
$httpRespText = null;
$jsonResult = [];

  if(isset($_GET['numbers'])){

    /* calculate and define result */
    $sumBuilder = new SumBuilder();
    $calculatedSum = $sumBuilder->calculateSum($_GET['numbers']);

    $primeChecker = new PrimeChecker();
    $isPrime = $primeChecker->isPrime($calculatedSum);

    /* responce result */
    $jsonResult['result'] = $calculatedSum;
    $jsonResult['isPrime'] = $isPrime;
    echo json_encode($jsonResult);
    http_response_code($httpOkRespNumber);

  }else{

    /* else, parameters not found */
    $httpBadRequest = 400;
    $httpRespText = "404 Not Found";
    $jsonResult['result'] = 'undefined';
    $jsonResult['isPrime'] = 'undefined';
    $jsonResult['error'] = 'numbers not defined';
    echo json_encode($jsonResult);
    http_response_code($httpBadRequest);
    header(trim("HTTP/1.1 $httpBadRequest $httpRespText"));
  }

?>
